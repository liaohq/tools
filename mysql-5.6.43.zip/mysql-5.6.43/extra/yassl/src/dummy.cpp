/*
  To make libtool always use a C++ linker when compiling with yaSSL we need
  to add a dummy C++ file to the source list.
*/
